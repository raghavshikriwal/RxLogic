# RxLogic

A neuro-symbolic AI agent for medication scheduling and drug-interaction
advisory. A small local LLM only parses free-text input into a typed
schema — every scheduling and safety decision is made by classical AI:
a forward-chaining rule engine, a CSP scheduler, a goal-stack planner,
and a fuzzy/Bayesian uncertainty layer. The system stays fully
functional with the LLM layer disabled.

This is an educational demonstrator, not a substitute for advice from a
pharmacist or physician.

## Stack

- **Backend** — Flask, pure-Python reasoning core, pgmpy / scikit-fuzzy
  for uncertainty, RxNav (NLM) + openFDA for drug data, SQLAlchemy
  (SQLite locally, Postgres in production).
- **Frontend** — React + Vite + Tailwind, served by Flask as static
  files so the whole app is one deployable service.

## Running locally

### 1. Backend

```bash
python -m venv .venv
source .venv/bin/activate          # .venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env               # fill in DATABASE_URL if using Postgres
python app.py                      # http://localhost:5000
```

Without `DATABASE_URL` set, the app falls back to an in-memory SQLite
database — fine for local development, but plan history won't persist
across restarts.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev                        # http://localhost:5173
```

The Vite dev server proxies `/api/*` to `http://localhost:5000`, so run
the Flask backend alongside it — no separate API URL configuration
needed in development.

### 3. Running the test suite

```bash
pytest -v --cov
```

The full suite passes with or without the frontend built — see
`tests/test_api.py::test_root_serves_frontend_or_build_notice`.

## Building for production

The backend serves the built frontend directly, so there's one
artifact to produce before deploying:

```bash
cd frontend
npm install
npm run build                      # outputs to frontend/dist
```

Then run the backend as usual (`python app.py`, or `gunicorn app:app`
per the `Procfile`). Flask serves `frontend/dist` at `/`, and every
`/api/*` route continues to work exactly as before. If `frontend/dist`
doesn't exist, `/` responds with a `503` explaining that the frontend
needs to be built, instead of crashing.

## Deploying (Render)

One service, using the existing `Procfile` (`web: gunicorn app:app`).
Add a build step that builds the frontend before starting gunicorn,
e.g. as Render's **Build Command**:

```bash
pip install -r requirements.txt && cd frontend && npm install && npm run build
```

Environment variables to set on Render: `DATABASE_URL` (Postgres
connection string — `postgres://` and `postgresql://` are both
accepted), `LOG_LEVEL` (optional, defaults to `INFO`).

## API

All endpoints are under `/api`. Full request/response shapes are in
`routes/api.py`; summary:

| Method | Path          | Description                                        |
|--------|---------------|-----------------------------------------------------|
| GET    | `/api/health` | Liveness check.                                      |
| GET    | `/api/info`   | Service metadata.                                    |
| POST   | `/api/plan`   | Structured medication list → `DailyPlan`.            |
| POST   | `/api/plan/nl`| Free-text description → `DailyPlan` (via the LLM parser). |
| GET    | `/api/plans`  | Most recently logged plans, newest first.            |

Every domain failure raises a typed exception (`models/exceptions.py`)
mapped to a specific HTTP status and a `{"error": ..., "message": ...}`
body — never a bare 500.

## Project layout

```
app.py                  Application factory; serves the API + built frontend
extensions.py           Shared Flask extensions (rate limiter)
models/                 Typed schemas, exceptions, persistence layer
routes/api.py           HTTP layer — JSON in/out, zero reasoning logic
services/               Reasoning core: rule engine, CSP scheduler,
                         planner, uncertainty layer, LLM parser
frontend/               React app (see frontend/ for its own structure)
tests/                  pytest suite, one file per module
```
